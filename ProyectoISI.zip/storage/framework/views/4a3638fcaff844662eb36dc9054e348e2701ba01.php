<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Reporte en PDF</title>
	<style>
		body {
			font-family: Helvetica;
		}
		table {
			border-collapse: collapse;
		}
		table th,
		table td {
			font-size: 14px !important;
		}
		table th {
			background-color: gray;
			color: white;
			text-align: center;
		}
		table td {
			border: 1px solid silver;
			padding: 10px;
		}
	</style>
</head>
<body>
	<table>
	<thead>
		<tr>
			<th> Id </th>
			<th> Nombre Completo </th>
			<th> Correo Electrónico </th>
			<th> Telefóno </th>
			<th> Fecha Nacimiento </th>
			<th> Genero </th>
			<th> Dirección </th>
			<th> Foto </th>
		</tr>
	</thead>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($user->id); ?> </td>
			<td> <?php echo e($user->fullname); ?> </td>
			<td> <?php echo e($user->email); ?> </td>
			<td> <?php echo e($user->phone); ?> </td>
			<td> <?php echo e($user->birthdate); ?> </td>
			<td> <?php echo e($user->gender); ?> </td>
			<td> <?php echo e($user->address); ?> </td>
			<td> <img src="<?php echo e(public_path() . '/' . $user->photo); ?>" width="40px"> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/users/pdf.blade.php ENDPATH**/ ?>