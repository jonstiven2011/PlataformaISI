<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('editor/index')); ?>">Mis Articulos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Consultar Articulo</li>
                </ol>
            </nav>
            
            <table class="table table-striped table-bordered table-hover">
                <tr>
                    <td colspan="2" class="text-center">
                    <img class="img-thumbnail" src="<?php echo e(asset($article->image)); ?>" width="200px">
                    </td>
                </tr>
                <tr>
                    <th>Nombre Articulo:</th>
                    <td><?php echo e($article->name); ?></td>
                </tr>
                <tr>
                    <th>Descripcion:</th>
                    <td><?php echo e($article->description); ?></td>
                </tr>
                <tr>
                    <th>Usuario:</th>
                    <td><?php echo e($user->fullname); ?></td>
                </tr>
                <tr>
                    <th>Categoria:</th>
                    <td><?php echo e($category->name); ?></td>
                </tr>
            </table>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/editor/show.blade.php ENDPATH**/ ?>