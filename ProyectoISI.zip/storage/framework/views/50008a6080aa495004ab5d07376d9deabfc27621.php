<?php if(isset($cat)): ?>

        <div class="card">   
            <div class="card-body">
                <img src="<?php echo e(asset($cat->image)); ?>" class="img-thumbnail" width="80px" height="80px">
                <label class="text-capitalize font-weight-bold" style="font-size: 1.5rem;"><?php echo e($cat->name); ?></label>
            </div>
                <div class="tab-content" id="pills-tabContent">
                    <?php $__currentLoopData = $artsbycats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($abc->category_id == $cat->id): ?>
                            <div class="tab-pane fade show active" id="showall" role="tabpanel" aria-labelledby="showall-tab">
                                <div class="Portfolio"><img src="<?php echo e(asset($abc->image)); ?>"><div class="desc"><?php echo e($abc->description); ?></div></div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div> 
<?php endif; ?>   

<?php if(isset($cats)): ?>

        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">   
                <div class="card-body">
                    <img src="<?php echo e(asset($cat->image)); ?>" class="img-thumbnail" width="80px" height="80px">
                    <label class="text-capitalize font-weight-bold" style="font-size: 1.5rem;"><?php echo e($cat->name); ?></label>
                </div>
                    <div class="tab-content" id="pills-tabContent">
                        <?php $__currentLoopData = $artsbycats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($abc->category_id == $cat->id): ?>
                                <div class="tab-pane fade show active" id="showall" role="tabpanel" aria-labelledby="showall-tab">
                                    <div class="Portfolio"><img src="<?php echo e(asset($abc->image)); ?>"><div class="desc"><?php echo e($abc->description); ?></div></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
<?php endif; ?>                                  
    <?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/loadcat.blade.php ENDPATH**/ ?>