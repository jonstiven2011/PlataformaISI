<title>Crear Clase <?php echo $__env->yieldContent('title'); ?></title>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
        <div class="col-md-8 offset-md-2">
            <h1 class="h3">
                <i class="fa fa-plus"></i>
                Adicionar Clase
            </h1>
            <hr>

            
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('clases')); ?>">Lista de Clases</a></li>
                <li class="breadcrumb-item active" aria-current="page">Adicionar Modulo</li>
                </ol>
            </nav>
        <form action="<?php echo e(url('clases')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <label for="name" class="text-md-right">Nombre Clase</label>

                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>"  autocomplete="name" autofocus>

                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="description" class="text-md-right">Descripción</label>

                    <input id="description" type="texto" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description" value="<?php echo e(old('description')); ?>"  autocomplete="description">

                    <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div> 
                
                <div class="form-group">
                    <label for="instrucciones" class="text-md-right">instrucciones 1</label>
                    <button class="btn btn-indigo btn-block btn-uploadpdf <?php if ($errors->has('instrucciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('instrucciones'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="button">
                        <i class="fa fa-upload"></i>
                        Seleccionar PDF
                    </button>

                    <input id="instrucciones" type="file" class="form-control-file <?php if ($errors->has('instrucciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('instrucciones'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> d-none" name="instrucciones">
                    <br>
            
                    <?php if ($errors->has('instrucciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('instrucciones'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="user" class="text-md-right">Usuario</label>
                    <input id="user" type="text" class="form-control <?php if ($errors->has('user')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="user" value="<?php echo e($user->fullname); ?>" autocomplete="user" autofocus disabled="true">
                </div> 
                
                <div class="form-group">
                    <label for="category" class="text-md-right">Curso</label>

                        <select name="curso" id="curso" class="form-control <?php if ($errors->has('curso')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('curso'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                            <option value="">Seleccione...</option>
                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($curso->id); ?>" <?php if(old('curso', $curso->curso) == $curso->id): ?> selected <?php endif; ?>><?php echo e($curso->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php if ($errors->has('curso')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('curso'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="video" class="text-md-right">Video</label>
                    <button class="btn btn-indigo btn-block btn-uploadd <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="button">
                        <i class="fa fa-upload"></i>
                        Seleccionar Video
                    </button>

                    <input id="video" type="file" class="form-control-file <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> d-none" name="video" >
                    <br>
                    
                    <div class="text-center">
                        
                        <video class="video-fluid"  id="previeww" autoplay loop muted width="120px">
                            <source src="<?php echo e(asset('mp4/no_video.mp4')); ?>" type="video/mp4" id="preview" >
                        </video>
                    </div>

                    <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="presentacion" class="text-md-right">Presentacion 1</label>
                    <button class="btn btn-indigo btn-block btn-uupload <?php if ($errors->has('presentacion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="button">
                        <i class="fa fa-upload"></i>
                        Seleccionar presentación
                    </button>

                    <input id="presentacion" type="file" class="form-control-file <?php if ($errors->has('presentacion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> d-none" name="presentacion">
                    <br>
                    
                    <div class="text-center">
                        <iframe src="<?php echo e(asset('presentaciones/no_presentacion_2.pptx')); ?>" id="preview" frameborder="0" width="320px"></iframe>
                    </div>

                    <?php if ($errors->has('presentacion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                

                
                <div class="form-group">
                    <label for="presentacion_2" class="text-md-right">Presentación 2</label>
                    <button class="btn btn-indigo btn-block btn-uppload <?php if ($errors->has('presentacion_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion_2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="button">
                        <i class="fa fa-upload"></i>
                        Seleccionar presentación 2
                    </button>

                    <input id="presentacion_2" type="file" class="form-control-file <?php if ($errors->has('presentacion_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion_2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> d-none" name="presentacion_2">
                    <br>
                    
                    <div class="text-center">
                        <iframe src="<?php echo e(asset('presentaciones/no_presentacion_2.pptx')); ?>" id="preview" frameborder="0" width="320px"></iframe>
                    </div>

                    <?php if ($errors->has('presentacion_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('presentacion_2'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="prezi" class="text-md-right">Link Prezi 1</label>

                    <input id="prezi" type="text" class="form-control <?php if ($errors->has('prezi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prezi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="prezi" value="<?php echo e(old('prezi')); ?>"  autocomplete="prezi" autofocus>

                    <?php if ($errors->has('prezi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prezi'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="prezi_2" class="text-md-right">Link Prezi 2</label>

                    <input id="prezi_2" type="text" class="form-control <?php if ($errors->has('prezi_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prezi_2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="prezi_2" value="<?php echo e(old('prezi_2')); ?>"  autocomplete="prezi_2" autofocus>

                    <?php if ($errors->has('prezi_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prezi_2'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="formulario" class="text-md-right">Link Formulario 1</label>

                    <input id="formulario" type="text" class="form-control <?php if ($errors->has('formulario')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('formulario'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="formulario" value="<?php echo e(old('formulario')); ?>"  autocomplete="formulario" autofocus>

                    <?php if ($errors->has('formulario')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('formulario'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                
                <div class="form-group">
                    <label for="formulario_2" class="text-md-right">Link Furmulario 2</label>

                    <input id="formulario_2" type="text" class="form-control <?php if ($errors->has('formulario_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('formulario_2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="formulario_2" value="<?php echo e(old('formulario_2')); ?>"  autocomplete="formulario_2" autofocus>

                    <?php if ($errors->has('formulario_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('formulario_2'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-indigo btn-block">
                        <i class="fa fa-save"></i>
                        Adicionar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\Isi\ProyectoISI\resources\views/clases/create.blade.php ENDPATH**/ ?>