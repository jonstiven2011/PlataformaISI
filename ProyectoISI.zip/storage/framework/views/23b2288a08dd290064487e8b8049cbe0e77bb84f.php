<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <!-- Inicio Tarjeta login-->
            <div class="card">
            <img src="<?php echo e(asset('imgs/autentication.png')); ?>" class="card-img-top">
                <div class="card-body">
                    <h3 class="title" align="center">
                        <i class="fa fa-lock"></i>
                        Ingreso de Usuarios</h3>
                    <hr>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <!--Campo Correo electronico-->
                        <div class="form-group ">
                            <i class="fa  fa-user"></i>
                            <label for="email" class="text-md-right">Correo Electronico:</label>
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <!--Campo Contraseña-->
                        <div class="form-group">
                            <i class="fa  fa-lock"></i>
                            <label for="password" class="text-md-right">Contraseña:</label>

                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <!--Boton de envio -->
                        <div class="form-group">
                            <button type="submit" class="btn btn-indigo btn-block">
                                <i class="fa fa-arrow-right"></i>
                                Ingresar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <!--Fin tarjeta login-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>