<title>Mis Cursos <?php echo $__env->yieldContent('title'); ?></title>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        
        
                <a href="<?php echo e(url('cursos/create')); ?>" class="btn btn-success">
                    <i class="fa fa-plus"></i>
                    Adicionar Curso
                </a>
                <br><br>
         
            <table class="table table-inverse table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombre Curso</th>
                        <th>Descripción</th>
                        <th>Foto</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($curso->name); ?></td>
                            <td><?php echo e($curso->description); ?></td>
                            <td><img src="<?php echo e(asset($curso->image)); ?>" width="40px"></td>
                            <td>
                                
                                <a href="<?php echo e(url('cursos/'.$curso->id)); ?>" class="btn btn-indigo btn-sm"> 
                                    <i class="fa fa-search"></i> 
                                </a>
                                
                                <a href="<?php echo e(url('cursos/'.$curso->id.'/edit')); ?>" class="btn btn-indigo btn-sm"> 
                                    <i class="fa fa-pen"></i> 
                                </a>
                                
                                <form action="<?php echo e(url('cursos/'.$curso->id)); ?>" method="post" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-danger btn-sm btn-delete">
                                      <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">
                            
                            <?php echo e($cursos->links()); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\Isi\ProyectoISI\resources\views/cursos/prueba.blade.php ENDPATH**/ ?>