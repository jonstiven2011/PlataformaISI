    <link href="<?php echo e(asset('css/galleryArticles.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
<?php $__env->startSection('content'); ?>

<h1 style="text-align:center;color:blank;">IMAGENES DE CATEGORIA</h1><br>

                                                                 
    <div align="center">
        <div class="content-select">
            <select name="catid" id="catid" class="form-control">
                <option value="">Seleccione una Categoria</option>
                <option value="0">Todas</option>
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <img src="<?php echo e(asset('imgs/loading.gif')); ?>" class="loader mt-5 d-none" height="100px">
            <i></i>
        </div>
    </div><br>
    

<div class="container" id="content">
    <?php echo csrf_field(); ?>
        <div class="container-fluid" style="margin-top:20px;">
            
            
            <div class="container">
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">   
                  <div class="card-body">
                    <img src="<?php echo e(asset($cat->image)); ?>" class="img-thumbnail" width="80px" height="80px">
                    <label class="text-capitalize font-weight-bold" style="font-size: 1.5rem;"><?php echo e($cat->name); ?></label>
                  </div>
                    <div class="tab-content" id="pills-tabContent">
                        <?php $__currentLoopData = $artsbycats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($abc->category_id == $cat->id): ?>
                                <div class="tab-pane fade show active" id="showall" role="tabpanel" aria-labelledby="showall-tab">
                                    <div class="Portfolio"><img src="<?php echo e(asset($abc->image)); ?>"><div class="desc"><?php echo e($abc->description); ?></div></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>