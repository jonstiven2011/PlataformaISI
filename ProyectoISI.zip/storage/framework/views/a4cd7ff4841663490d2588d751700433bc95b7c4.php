    <link href="<?php echo e(asset('css/galleryArticles.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>

<?php $__env->startSection('title','BIENVENIDO'); ?>

<?php $__env->startSection('content'); ?>


<div align="center">
    <h1 style="font-family: 'Times New Roman', Times, serif">Nuestra Sede vela por la capacidad de brindar el mejor conocimiento a sus estudiantes.</h1>
</div>
<br><br>

<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/salud.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="#" class="btn btn-indigo btn-block">Area de la Salud</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/investigacion.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('login')); ?>" class="btn btn-indigo btn-block">Area de Investigación</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/idioma.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="#" class="btn btn-indigo btn-block">Idiomas</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>






<footer id="sticky-footer" class="py-4 bg-primary text-dark-50">
    <div class="container text-center" style="font-size: 20px">
      <small >Copyright &copy; EMPRESA DE EDUCACIÓN I.S.I  S.A.S</small><br>
      <small >NIT 9011325814-2</small><br>
      <small >N° de Contacto: 3219815308</small>
    </div>
</footer>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\Isi\ProyectoISI\resources\views/welcome.blade.php ENDPATH**/ ?>