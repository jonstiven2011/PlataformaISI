<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Reporte de Mis Articulos</title>
	<style>
		body {
			font-family: Helvetica;
		}
		table {
			border-collapse: collapse;
		}
		table th,
		table td {
			font-size: 14px !important;
		}
		table th {
			background-color: gray;
			color: white;
			text-align: center;
		}
		table td {
			border: 1px solid silver;
			padding: 10px;
		}
	</style>
</head>
<body>
	<table>
	<thead>
		<tr>
			<th> Id </th>
			<th> Nombre Articulo </th>
			<th> Descripción </th>
			<th> Categoria </th>
			<th> Imagen </th>
		</tr>
	</thead>
	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($article->id); ?> </td>
			<td> <?php echo e($article->name); ?> </td>
			<td> <?php echo e($article->description); ?> </td>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($article->category_id == $category->id): ?>
					<td> <?php echo e($category->name); ?> </td>				
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			<td> <img src="<?php echo e(public_path() . '/' . $article->image); ?>" width="40px"> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/editor/pdf.blade.php ENDPATH**/ ?>