<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Reporte en PDF Categorias</title>
</head>
<body>
	<table>
        <thead>
            <tr>
                <th> Id </th>
                <th> Nombre Categoria </th>
                <th> Descripción </th>
                <th> Imagen </th>
            </tr>
        </thead>
	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($category->id); ?> </td>
			<td> <?php echo e($category->name); ?> </td>
			<td> <?php echo e($category->description); ?> </td>
            <td> <img src="<?php echo e(public_path() . '/' . $category->image); ?>" width="40px"> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/categories/excel.blade.php ENDPATH**/ ?>