<link href="<?php echo e(asset('css/galleryArticles.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card bg-light mt-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('users')); ?>">Lista de Usuarios</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Importar Usuarios</a></li>
                </ol>
            </nav>                
            <h2>
                Importar Usuarios
            </h2>
            <div class="card-body">
                <form action="<?php echo e(route('users.import.excel')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <?php if(Session::has('message')): ?>
                           
                        <?php endif; ?>

                    <label for="file-upload" class="subir">
                        <i class="fa fa-file-excel"></i> Seleccionar archivo Excel
                    </label>
                        <input id="file-upload" onchange='cambiar()' type="file" name="file" style='display: none;'/>
                        <div id="info"></div>
                        
                    <button class="btn btn-success btn-excel"><i class="fas fa-cloud-upload-alt"></i> Importar Usuarios</button>
                </form>
               
            </div>
        </div>
    </div>

    <script>
        function cambiar(){
            var pdrs = document.getElementById('file-upload').files[0].name;
            document.getElementById('info').innerHTML = pdrs;
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/import.blade.php ENDPATH**/ ?>