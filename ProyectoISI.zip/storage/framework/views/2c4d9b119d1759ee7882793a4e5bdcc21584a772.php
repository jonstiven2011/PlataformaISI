<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        
                <a href="<?php echo e(url('articles/create')); ?>" class="btn btn-success">
                    <i class="fa fa-plus"></i>
                    Adicionar Articulo
                </a>
                <a href="<?php echo e(url('generate/pdf/articles')); ?>" class="btn btn-indigo">
                    <i class="fa fa-file-pdf"></i> 
                    Generar Reporte PDF
                </a>
                <a href="<?php echo e(url('generate/excel/articles')); ?>" class="btn btn-indigo">
                    <i class="fa fa-file-excel"></i> 
                    Generar Reporte EXCEL
                </a>
                <br><br>
         
            <table class="table table-inverse table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombre Articulo</th>
                        <th>Descripción</th>
                        <th>Imagen</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($article->name); ?></td>
                            <td><?php echo e($article->description); ?></td>
                            <td><img src="<?php echo e(asset($article->image)); ?>" width="40px"></td>
                            <td>
                                
                                <a href="<?php echo e(url('articles/'.$article->id)); ?>" class="btn btn-indigo btn-sm"> 
                                    <i class="fa fa-search"></i> 
                                </a>
                                
                                <a href="<?php echo e(url('articles/'.$article->id.'/edit')); ?>" class="btn btn-indigo btn-sm"> 
                                    <i class="fa fa-pen"></i> 
                                </a>
                                
                                <form action="<?php echo e(url('articles/'.$article->id)); ?>" method="post" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-danger btn-sm btn-delete">
                                      <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">
                            
                            <?php echo e($articles->links()); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/articles/index.blade.php ENDPATH**/ ?>