<title>Mi Curso <?php echo $__env->yieldContent('title'); ?></title>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
        <div class="col-md-8 offset-md-2">
            <h1 class="h3">
                <i class="fa fa-search"></i>
                Consultar Curso
            </h1>
            <hr>
            
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('categories')); ?>">Lista de Cursos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Consultar Curso</li>
                </ol>
            </nav>
            
            <table class="table table-striped table-bordered table-hover">
                <tr>
                    <td colspan="2" class="text-center">
                    <img class="img-thumbnail" src="<?php echo e(asset($curso->image)); ?>" width="200px">
                    </td>
                </tr>
                <tr>
                    <th>Nombre:</th>
                    <td><?php echo e($curso->name); ?></td>
                </tr>
                <tr>
                    <th>Descripción:</th>
                    <td><?php echo e($curso->description); ?></td>
                </tr>
            </table>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\Isi\ProyectoISI\resources\views/cursos/show.blade.php ENDPATH**/ ?>