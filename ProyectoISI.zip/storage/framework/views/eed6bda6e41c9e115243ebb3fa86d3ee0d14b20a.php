<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/users.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('users')); ?>" class="btn btn-indigo btn-block">Módulo Usuarios</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/categories.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('categories')); ?>" class="btn btn-indigo btn-block">Módulo Categorías</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/articles.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('articles')); ?>" class="btn btn-indigo btn-block">Módulo Artículos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/home.blade.php ENDPATH**/ ?>