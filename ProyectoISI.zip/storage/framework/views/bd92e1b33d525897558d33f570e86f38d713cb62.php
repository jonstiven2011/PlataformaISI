<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
        <div class="col-md-8 offset-md-2">
            <h1 class="h3">
                <i class="fa fa-search"></i>
                Consultar Usuario
            </h1>
            <hr>
            
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('users')); ?>">Lista de Usuarios</a></li>
                <li class="breadcrumb-item active" aria-current="page">Consultar Usuario</li>
                </ol>
            </nav>
            
            <table class="table table-striped table-bordered table-hover">
                <tr>
                    <td colspan="2" class="text-center">
                    <img class="img-thumbnail" src="<?php echo e(asset($user->photo)); ?>" width="200px">
                    </td>
                </tr>
                <tr>
                    <th>Nombre Completo:</th>
                    <td><?php echo e($user->fullname); ?></td>
                </tr>
                <tr>
                    <th>Correo Electronico:</th>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <th>Telefono:</th>
                    <td><?php echo e($user->phone); ?></td>
                </tr>
                <tr>
                    <th>Fecha de Nacimiento:</th>
                    <td>
                        <?php echo e($user->birthdate); ?>

                        &nbsp; | &nbsp;
                        <?php use \Carbon\Carbon; ?>
                        <?php echo e(Carbon::createFromDate($user->birthdate)->diff(Carbon::now())->format('%y años, %m meses y %d días')); ?>

                        
                    </td>
                </tr>
                <tr>
                    <th>Genero:</th>
                    <td>
                        <?php if($user->gender == "Female"): ?>
                            Mujer
                        <?php else: ?> 
                            Hombre
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Dirección:</th>
                    <td><?php echo e($user->address); ?></td>
                </tr>
                
                

            </table>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/users/show.blade.php ENDPATH**/ ?>