<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/users.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('users')); ?>" class="btn btn-indigo btn-block">Mis Usuarios</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/cursos.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('cursos')); ?>" class="btn btn-indigo btn-block">Mis Cursos</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card">
                    <img src="<?php echo e(asset('imgs/ISI/icons/clases.png')); ?>" class="card-img-top" height="240px">
                    <div class="card-body">
                        <a href="<?php echo e(url('clases')); ?>" class="btn btn-indigo btn-block">Mis Clases</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\Isi\ProyectoISI\resources\views/home.blade.php ENDPATH**/ ?>