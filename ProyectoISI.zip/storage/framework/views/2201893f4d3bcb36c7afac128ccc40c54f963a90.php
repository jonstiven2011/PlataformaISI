<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        
            <a href="<?php echo e(url('users/create')); ?>" class="btn btn-success">
                <i class="fa fa-plus"></i>Adicionar Usuario
            </a>
            <br><br>
         
            <table class="table table-inverse table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombre Completo</th>
                        <th>Correo Electronico</th>
                        <th>Foto</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->fullname); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><img src="<?php echo e(asset($user->photo)); ?>" width="40px"></td>
                            <td>
                            <a href="<?php echo e(url('users/'.$user->id)); ?>" class="btn btn-indigo btn-sm"> <i class="fa fa-search"></i> </a>
                                <a href="<?php echo e(url('users/'.$user->id.'/edit')); ?>" class="btn btn-indigo btn-sm"> <i class="fa fa-pen"></i> </a>
                                <a href="" class="btn btn-danger btn-sm"> <i class="fa fa-trash"></i> </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">
                            
                            <?php echo e($users->links()); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\mcds2019-master\laravel\resources\views/users/index.blade.php ENDPATH**/ ?>