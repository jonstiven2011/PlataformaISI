    <link href="<?php echo e(asset('css/galleryArticles.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->startSection('content'); ?>

<div class="container">

    <!------ Include the above in your HEAD tag ---------->
    
    <div class="container-fluid" style="margin-top:20px;">
    <h1 style="text-align:center;color:blank;">IMAGENES DE CATEGORIA</h1><br>
    
    <div class="row">
        <ul class="nav nav-pills mb-3 text-center" id="pills-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="showall-tab" data-toggle="pill" href="#showall" role="tab" aria-controls="showall" aria-selected="true">Show All</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="Cars-tab" data-toggle="pill" href="#Cars" role="tab" aria-controls="Cars" aria-selected="false">Cars</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="City-tab" data-toggle="pill" href="#City" role="tab" aria-controls="City" aria-selected="false">City</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="Forest-tab" data-toggle="pill" href="#Forest" role="tab" aria-controls="Forest" aria-selected="false">Forest</a>
            </li>
        </ul>
    </div>
    <hr noshade style="margin-top:-20px;">

    
   
    
    </div>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\STIVEN\Desktop\mcds2019\laravel\laravel\resources\views/Welcome.blade.php ENDPATH**/ ?>